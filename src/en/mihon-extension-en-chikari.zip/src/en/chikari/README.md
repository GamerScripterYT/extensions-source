# Chikari Mihon / Tachiyomi Extension

This extension is built for the **Keiyoushi Extensions Repository** (the official community extension catalog for Mihon).

## Directory Structure in Keiyoushi

Place this folder at:
```
keiyoushi/extensions/src/en/chikari/
  ├── build.gradle.kts
  ├── AndroidManifest.xml (optional if inherited from common.gradle)
  ├── res/
  │   └── mipmap-xxxhdpi/
  │       └── ic_launcher.png (192x192 icon)
  └── src/
      └── eu/kanade/tachiyomi/extension/en/chikari/
          └── Chikari.kt
```

## Building and Testing Locally

1. Clone the Keiyoushi repo:
   ```bash
   git clone https://github.com/keiyoushi/extensions.git
   cd extensions
   ```

2. Copy this generated folder into `src/en/chikari`.

3. Assemble the debug APK:
   ```bash
   ./gradlew :src:en:chikari:assembleDebug
   ```

4. Install to your connected Android device or emulator:
   ```bash
   adb install src/en/chikari/build/outputs/apk/debug/chikari-debug.apk
   ```

5. Open **Mihon** &rarr; **Browse** &rarr; **Sources** to test your new extension!
